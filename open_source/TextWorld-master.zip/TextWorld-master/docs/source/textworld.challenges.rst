textworld.challenges
====================

.. automodule:: textworld.challenges
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: textworld.challenges.coin_collector
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: textworld.challenges.treasure_hunter
    :members:
    :undoc-members:
    :show-inheritance:
