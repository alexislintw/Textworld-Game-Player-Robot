Wrappers
========

.. automodule:: textworld.envs.wrappers
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: textworld.envs.wrappers.recorder
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: textworld.envs.wrappers.viewer
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: textworld.envs.wrappers.filter
    :members:
    :undoc-members:
    :show-inheritance:
