Inform 7
========

.. automodule:: textworld.generator.inform7
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: textworld.generator.inform7.world2inform7
    :members:
    :undoc-members:
    :show-inheritance:
