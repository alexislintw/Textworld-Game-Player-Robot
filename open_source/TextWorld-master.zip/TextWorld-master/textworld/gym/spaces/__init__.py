from textworld.gym.spaces.text_spaces import Char
from textworld.gym.spaces.text_spaces import Word
