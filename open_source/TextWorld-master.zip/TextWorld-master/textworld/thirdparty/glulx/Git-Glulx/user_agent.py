def evaluate(words):
    return ('n', False)
